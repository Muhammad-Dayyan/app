

// function add() {
//     let name = document.getElementById("text").value
//     if (name == '') {
//         document.getElementById('error').innerHTML = 'please enter the value'
//     } else {
//         let box = document.getElementById('box')
//         let li = document.createElement('li')
//         li.textContent = name
//         let a = document.createElement('a')
//         a.textContent  =   "x"
//         a.href = ("javascript:void(0)")
//         a.className = "remove"
//         li.appendChild(a)

//         let pos = box.firstElementChild;
//         if (pos == null) {
//             box.appendChild(li)
//         }
//         else {
//             box.insertBefore(li, pos)
//         }

//     }
//     document.getElementById("text").value = ""
// }

// function check(){
//     var score=0
//     var html=document.getElementById('q1')
//     var html2=document.getElementById('q2')
//     var html3=document.getElementById('q3')
//     var html4=document.getElementById('q4')
//     if(html.checked == true){
//         score++
//         alert("your answer is right")
//     }{
//         alert("your answer is wrong")
//     }
//     var pak=document.getElementById('ind')
//     var pak2=document.getElementById('dep')
//     var pak3=document.getElementById('pen')
//     var pak4=document.getElementById('dence')
//     if(pak.checked == true){
//         score++
//         alert("your answer is right")

//     }{
//         alert("your answer is wrong")
//     }
//     var city=document.getElementById('pa')
//     var city2=document.getElementById('ki')
//     var city3=document.getElementById('is')
//     var city4=document.getElementById('tan')
//     if(city.checked == true){
//         score++
//         alert("your answer is right")
//     }{
//         alert("your answer is wrong")
//     }
//     alert("your score is " + score++)
// }
